API_TOKEN = "KGdAEDop1kAwRtPlb9ytokYW9efprvCqRiUzTtDkqc32ylbgX5fbGILYl19AFfXx"
API_URL = "https://server.simpletex.cn/api/latex_ocr"  # 替换为实际的 API 地址